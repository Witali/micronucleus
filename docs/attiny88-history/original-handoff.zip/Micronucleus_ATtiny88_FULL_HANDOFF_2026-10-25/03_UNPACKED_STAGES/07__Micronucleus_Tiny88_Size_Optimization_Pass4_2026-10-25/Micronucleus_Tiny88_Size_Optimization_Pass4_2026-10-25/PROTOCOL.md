# Протокол Micronucleus+ v2.8 / v2.9

Все операции — USB EP0 vendor control-IN (bmRequestType=0xC0).
Старые Micronucleus bRequest 0..4 сохраняются в неизменном виде.

| bRequest | Имя | wValue | wIndex | wLength | Ответ |
| 0x00 | INFO | 0 | 0 | 8 | 8 байт Micronucleus; бит 0x40=EEPROM, 0x80=Flash READ |
| 0xA0 | EEPROM READ | 0..63 | 0 | 1 | 1 байт данных, при неверном адресе 0 байт |
| 0xC0 | EEPROM WRITE | 0..63 | low=данные, high=0 | 1 | 0 принято; 1 занято; 2 неверные параметры |
| 0xF0 | EEPROM BUSY | 0 | 0 | 1 | 0 свободно; 1 занято |
| 0xB0 | USER FLASH READ | адрес | 0 | 1–8 (2.8) / только 1 (2.9) | Байты по адресу |

Запрос 0xB0 всегда ограничен областью [0,BOOT_AT-4): 0..6779 (v2.8 Fast)
или 0..6843 (v2.9 Compact). Физические байты RESET-вектора прочитаны после
подмены загрузчиком, оригинальный RESET находится в зарезервированном постскрипте,
который недоступен для чтения через 0xB0.

Версии определяются по USB device descriptor `bcdDevice`: 0x0208 или 0x0209.
`GET_INFO[7]` — НЕ версия протокола, это поле версии приложения.
