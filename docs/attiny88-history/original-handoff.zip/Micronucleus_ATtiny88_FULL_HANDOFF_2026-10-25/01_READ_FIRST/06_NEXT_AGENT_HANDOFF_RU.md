# Сообщение для следующего агента

Продолжи разработку проекта **Micronucleus+ для MH-Tiny88 / ATtiny88 16 МГц** на основе приложенного архива. Обязательно сначала прочитай `01_READ_FIRST/00_START_HERE_RU.md`, хронологию, таблицу версий, протокол и README `04_CURRENT_RECOMMENDED/Fast_Pass7_1320_experimental`.

**Исходное состояние**: последнее ASM Fast Pass7 на **1320 Б** (`0x1AC0`), быстрый Flash Read до 8 Б за USB-запрос, запись Flash, EEPROM read/write, ПК-утилита Python, базовые Micronucleus команды; приложение 6844 Б. Есть conservative strict USB **1328 Б** — предпочтителен для первых аппаратных тестов. CRC USB обязательна; отдельная CRC диапазонов **отклонена**, т.к. проверка делается на ПК после чтения.

**Приоритеты:**
1. Подтвердить корректность сборки на AVR ISA: 16 МГц, регистры, W1C, SPM EEPROM, защита загрузчика, все границы. Запускать тесты из Pass7 и корректировать тестовый стенд, если он показывает ложный успех/ошибку.
2. Подготовить **работающий ASM Self-Updater для ATtiny88**: старый USB-загрузчик принимает временную программу приложения, та меняет bootloader через SPM, verify и reset. Обеспечить безопасную последовательность записи и честно указать риск потери питания. За основу взять upstream `firmware/upgrade.c` для ATtiny85, но адаптировать под ATtiny88.
3. При желании уменьшать загрузчик к рубежу **1280 Б** (ещё минус 40 Б от Pass7), **не** ухудшая USB timing. Оптимизация общего диспетчера важнее микрозамены пары команд. Размер измерять по реально линкованному BIN и целым страницам.
4. Сохранить backward compatibility Micronucleus CLI, fast Flash Read 8 Б, EEPROM, host Python, не встраивать тяжёлую CRC диапазонов.
5. На реальной плате с резервным ISP протестировать USB enumeration, загрузку/чтение Flash, EEPROM, watchdog, brownout, прерывания и сам upgrade при разных сценариях сбоя питания.

**Отдельно:** доказательства соответствия USB по эмуляции недостаточны для утверждения аппаратной надёжности. Не ставить экспериментальный HEX на единственную плату без резервного способа восстановления.

**Основные файлы:**
- `04_CURRENT_RECOMMENDED/Fast_Pass7_1320_experimental/source/micronucleus_t88_plus.S`
- `04_CURRENT_RECOMMENDED/Fast_Pass7_1320_experimental/host/micronucleus_plus.py`
- `04_CURRENT_RECOMMENDED/Fast_Pass7_1320_experimental/firmware/ISP_FULL_1AC0_PLUS_FRESH_ONLY.hex`
- `04_CURRENT_RECOMMENDED/Strict_USB_1328_preferred_for_first_hardware_trials/micronucleus_t88_plus_strict.S`
- Все архивы исторических версий в `02_ORIGINAL_ARCHIVES`, их содержимое в `03_UNPACKED_STAGES`.
