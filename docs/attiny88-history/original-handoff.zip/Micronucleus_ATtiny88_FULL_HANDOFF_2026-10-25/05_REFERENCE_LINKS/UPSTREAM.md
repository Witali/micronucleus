# Публичные исходники и документация

- Micronucleus оригинальный: https://github.com/micronucleus/micronucleus
- Зафиксированный при исследовании коммит в upstream: `4dd1b49f39cd9d6fc736a720777ed62f4564e0e2` (2026-02-06). Если требуется точная версия источников, использовать этот SHA.
- Оригинальный self-updater для ATtiny85: https://github.com/micronucleus/micronucleus/blob/master/firmware/upgrade.c
- Конфигурация платы: https://github.com/micronucleus/micronucleus/tree/master/firmware/configuration/t88_default
- Оригинальный USBasp (для сравнения с AVR ISP): https://www.fischl.de/usbasp/
- Репозиторий-зеркало USBasp с исходниками ISP: https://github.com/wojtekka/usbasp
- AVR ISA Microchip: https://ww1.microchip.com/downloads/en/DeviceDoc/AVR-InstructionSet-Manual-DS40002198.pdf
- ATtiny48/88 Datasheet: https://ww1.microchip.com/downloads/en/DeviceDoc/doc8008.pdf

Ссылки приведены для происхождения кода и дальнейшей проверки. Полный upstream Git-клон и побуквенный экспорт беседы в данную сборку не входят; зато оригинальные **десять ранее созданных исследовательских архивов** и всё их содержимое сохранены локально.
