#!/usr/bin/env python3
"""Offline integrity checks; cannot prove physical USB compatibility."""
from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256

R=Path(__file__).resolve().parent.parent

def hex_cells(text):
    cells={}
    top=0
    eof=False
    for i,line in enumerate(text.splitlines(),1):
        if not line.strip(): continue
        assert line.startswith(':'),i
        record=bytes.fromhex(line[1:].strip())
        count=record[0]
        assert len(record)==count+5 and sum(record)%256==0, ('bad HEX',i)
        addr=(record[1]<<8)|record[2]
        ty=record[3]
        if ty==0:
            for j,b in enumerate(record[4:-1]):
                a=(top<<16)+addr+j
                assert a not in cells or cells[a]==b,('conflicting HEX',hex(a))
                cells[a]=b
        elif ty==4:
            top=(record[4]<<8)|record[5]
        elif ty==1:
            eof=True
        elif ty in (3,5):
            pass
        else:
            raise AssertionError(('unknown record type',ty))
    assert eof
    return cells

archives=sorted((R/'02_ORIGINAL_ARCHIVES').glob('*.zip'))
assert len(archives)==10,len(archives)
for p in archives:
    with ZipFile(p) as z:
        assert z.testzip() is None,p.name
P=R/'04_CURRENT_RECOMMENDED/Fast_Pass7_1320_experimental'
body=(P/'firmware/BOOTLOADER_BODY_1AC0_PLUS.bin').read_bytes()
assert len(body)==1320
assert sha256(body).hexdigest()=='6f573edc063f1e7751d551ac2ee3384ecfc92d807fa2db5e279e1d063327413d'
image=(P/'firmware/ISP_FULL_8192_1AC0_FRESH_ONLY.bin').read_bytes()
assert len(image)==8192
assert image[0:2] == (0xC000|(((0x1AC0//2)-1)&0xFFF)).to_bytes(2,'little')
assert image[0x1AC0:0x1AC0+len(body)]==body
assert image[0x1ABC:0x1AC0]==bytes([255])*4
cells=hex_cells((P/'firmware/ISP_FULL_1AC0_PLUS_FRESH_ONLY.hex').read_text())
assert cells[0]==image[0] and cells[1]==image[1]
for addr in range(0x1AC0,0x1AC0+len(body)):
    assert cells.get(addr,255)==image[addr],hex(addr)
assert len((R/'04_CURRENT_RECOMMENDED/Strict_USB_1328_preferred_for_first_hardware_trials/BOOTLOADER_BODY_1AC0_STRICT_1328.bin').read_bytes())==1328
print('PASS: 10 historical ZIPs, no corrupt files')
print('PASS: 1320B Pass7 body, checksum, HEX, RESET, POSTCRIPT, Flash placement')
print('PASS: 1328B strict alternative exists')
print('CAUTION: NO HARDWARE/USB ELECTRICAL TEST WAS DONE')
