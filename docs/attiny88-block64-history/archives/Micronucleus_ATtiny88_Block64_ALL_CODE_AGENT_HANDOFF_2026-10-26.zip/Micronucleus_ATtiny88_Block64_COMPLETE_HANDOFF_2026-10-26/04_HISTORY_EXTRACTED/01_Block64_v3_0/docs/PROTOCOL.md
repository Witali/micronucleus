# Block64 USB protocol v3.0 / ATtiny88

**Transport:** USB 1.5 Mbit/s Low-Speed, control endpoint 0 (`wMaxPacketSize0=8`), VID:PID `16d0:0753`, `bcdDevice=0x0300` (non-backwards-compatible with the Micronucleus 2.x CLI).

Setup packet is standard 8-byte USB SETUP:

| Byte offset | Field | Meaning |
|---|---|---|
| 0 | bmRequestType | `0xC0` vendor IN, `0x40` vendor OUT |
| 1 | bRequest | command |
| 2..3 | wValue | little-endian byte address |
| 4..5 | wIndex | memory kind 0=Flash, 1=EEPROM |
| 6..7 | wLength | 16-bit byte count (restricted to 1..64 in READ/WRITE) |

## Commands

`0x10 READ`: IN, 1..64 bytes, Flash addresses 0..`BOOT_AT-1`, EEPROM 0..63. Request may cross Flash page boundary. Device sends 1..8 DATA packets of up to 8 bytes. The host finishes with zero-length OUT status. RAM-backed EEPROM snapshot uses 64-byte SRAM buffer. Flash direct read uses LPM. Reads of four-byte reset postscript are allowed, bootloader region is not.

`0x11 WRITE`: OUT, 1..64 bytes. Host issues SETUP then 1..8 DATA OUT packets, then reads zero-length DATA1 IN status after memory programming finishes. Flash writes must be contained within one aligned 64-byte page. For arbitrary multi-page writes the PC tool splits at boundaries. EEPROM write progresses bytewise after receiving all DATA. Write result is queried through a separate `STATUS` request and verified by readback.

`0x12 STATUS`: IN, returns one byte: `0` successful/idle, `1` operation in progress, `2` invalid address/parameters, `3` general error. A USB transfer error (including unexpected message length) is separately reported by libusb, not encoded in this byte.

`0x13 RUN`: OUT with zero wLength. The loader sends STATUS IN ZLP, then transfers control to the application postscript.

`0x20 INFO`: IN, exactly 8 bytes (`[app_size_hi,app_size_lo,page_size,write_delay,sig2,sig3,features,application_version]`). App size excludes four bytes of reset postscript. Features bit 0=Block64 protocol. For this profile: `[0x19,0x7C,0x40,0x05,0x93,0x11,0xE1,0x00]`.

## Read example: Flash at 0x0100, length 64

SETUP C0 10 00 01 00 00 40 00 (wLength 0x0040).

Device responds with 8 sequential IN DATA packets, each 8 bytes, DATA1 and DATA0 alternating, CRC16 per packet, followed by host zero-length OUT status. No 64-byte USB Low-Speed packet is sent.

## Write example: EEPROM at 0x0020, length 16

SETUP 40 11 20 00 01 00 10 00, then DATA1 (8 payload bytes), DATA0 (8 payload bytes), then device sends zero-length DATA1 IN when EEPROM programming completes. No second SETUP is needed within this 16-byte USB transfer.

## SRAM state

`0x0100..0x012B`: original V-USB context. `0x0130..0x0139`: Block64 state, memory kind, address, remaining, index, total, result, progress, expected DATA PID. `0x0140..0x017F`: 64-byte memory buffer. EEPROM READ uses this buffer for DATA IN; WRITE uses it for DATA OUT; Flash writes use read-modify-write page staging.

`0x0102..0x0109`: V-USB TX payload. In USB response source pointer, high-byte flag bit7 indicates SRAM source. The legacy standard-request scratch marker 0x810A means payload is already in TX buffer. Flash source uses normal 16-bit pointer (LPM). SRAM source uses LD and pointer auto increment.

## Flash upload / RESET

App bytes 0x0000..0x197B; postscript 0x197C..0x197F; loader starts 0x1980. Program page size is 64. When the first page is written, MCU forcibly sets the first two bytes to RJMP loader (`0xCCBF` little-endian BF CC). Host stores the original app RESET destination as an RJMP word at postscript 0x197C. Remaining two postscript bytes stay 0xFF.

## Safety invariants

- Reject size0, size>64, high byte of wLength !=0, memory type !=0/1, out-of-range or 16-bit overflow.
- Reject Flash writes crossing page boundary or entering bootloader.
- Reject/write timeout rather than silently accept malformed requests.
- PID duplicate handling suppresses repeated DATA payload appends.
- USB receive payload CRC16 is checked with the original V-USB CRC subroutine, outside of the bit-level packet RX routine. The existing low-level ACK occurs before this later validation, so malformed packets cannot be treated as fully USB-compliant error recovery.
- Flash Page Erase / Page Fill / Page Write execute in main, never in bit-level sampling; a control OUT status is not queued until completion.
- EEPROM EEPE programming is spread across main-loop iterations; an unfinished Flash page buffer is not interleaved with EEPROM.
- Hardware verification is required. In particular, ACK/NAK and lost IN ACK behavior were not proved by physical trace or a full USB transaction-level simulator.
