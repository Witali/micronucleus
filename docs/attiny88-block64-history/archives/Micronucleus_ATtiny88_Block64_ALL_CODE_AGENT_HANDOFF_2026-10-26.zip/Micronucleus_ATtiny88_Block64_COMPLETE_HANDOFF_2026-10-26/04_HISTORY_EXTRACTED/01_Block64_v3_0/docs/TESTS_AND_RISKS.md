# Block64: evidence and open risks

## What was executed (October 26, 2026)

1. `clang -target avr -mmcu=attiny88 -c -x assembler-with-cpp`: firmware compiles.
2. `llvm-objcopy`: exact Flash binary generated and Intel HEX checksummed.
3. Both the 508-byte low-level V-USB RX/TX handler and the 44-byte USB CRC16 subroutine are byte-identical to the 1344-byte prior firmware. Verified against a separately compiled baseline.
4. Emulated actual AVR opcode execution (not only high-level Python functions): tests for every legal EEPROM/Flash address bound, 1..64 bytes, partial Flash page RMW, full 64-byte writes, 64 EEPROM byte programming steps, packet PID duplicates, bad USB RX CRC, SRAM/Flash 8 x 8-byte TX source selection, SPM Page Erase/Fill/Write, protected RESET, status, run setup.
5. Randomized 70 Flash page+range RMW scenarios and 30 EEPROM write-range scenarios.
6. Host-side mock libusb tests: 64/256-byte reads, 64-byte EEPROM write, splitting crossing-Flash-page writes, upload postscript patch and ordering, checksum-valid Intel HEX, invalid request rejection, version protection.
7. Entire compiled code walked by AVR instruction decoder; branch targets match legal instruction boundaries, except intended RJMP into app reset postscript.
8. `pytest`: 32 tests pass in this snapshot.

## What was NOT tested

- Real MH-Tiny88 board, 16 MHz electrical clock, USB D+/D− waveform, USB host polling, enumeration or cross-OS drivers.
- Full USB SETUP/DATA0/DATA1/ACK/NAK/STATUS re-transmission state in real hardware.
- Self-upgrade by using only the current board; **first flash must be programmed via ISP** and an ISP recovery path should remain available.
- Power-failure while erasing Flash page 0. Loss of RESET vector during this narrow window may make ISP mandatory.
- Lock bits and fuse settings of the user's particular board.

## Known protocol limitations

- The optimized historical V-USB engine emits ACK for an incoming DATA packet before the newly added main-loop CRC check. On a CRC mismatch the payload is discarded, but the host may not retry because ACK was already sent. The transfer can time out, rather than finishing with corrupted EEPROM/Flash. **This is not a complete USB RX CRC/ACK implementation.**
- On a lost host ACK for an IN packet, the historical transmitter may have already advanced its source pointer before the retransmission. Handling this exactly requires a transaction-level ACK-aware redesign, unimplemented here.
- Flash page Erase and Write each halt the ATtiny88 CPU while SPM runs. The resulting USB response pauses are expected to be tolerated by the host retry mechanism but are not proven by hardware test.
- Long EEPROM writes (up to 64 cells) may require a few hundred milliseconds; the host uses 6-second control-transfer timeouts.
- Legacy Micronucleus 2.x CLI / Arduino board upload recipe cannot operate the new protocol v3.0. Replace host command with `micronucleus_block64.py`.
- USB VID/PID must remain used in accordance with its original licensing/assignment rules.

## Next hardware-validation order

1. Use a spare board with working ISP programmer and known fuse backup.
2. Program only a status/INFO debug build; confirm v3.0 enumeration under Linux and Windows.
3. Capture D+/D− while requesting INFO and 1/8/64 byte reads, including full-speed/high-speed hubs.
4. Verify multiple DATA OUT packet write, exact wLength, DATA PID toggles, CRC faults and retransmissions; look for ACK-state issues above.
5. Program EEPROM with known data and verify full 64B roundtrip; use external ISP readback as independent ground truth.
6. Program application Flash at nonzero page only, read back by ISP; finally test page0 and RESET/postscript on recoverable spare board.
7. Run repeated uploads and intentional power interruptions only with guaranteed ISP recovery.

Referenced official specs: Microchip ATtiny48/88 Datasheet (Self-Programming and EEPROM), Microsoft Windows USB documentation "How to Send a USB Control Transfer" (Low-Speed EP0 packet size 8B and Control Transfer stages).
