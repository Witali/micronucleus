# Структура исходников ASM

Этот вариант **единого firmware ELF из нескольких текстовых include-фрагментов**: он компилируется одной командой `clang -target avr -mmcu=attiny88 -c -x assembler-with-cpp source/micronucleus_t88_block64.S`.

| Файл | Ответственность |
|---|---|
| `source/device_attiny88.inc` | Все характерные для ATtiny88 определения: частота 16 МГц, FLASH/SRAM/EEPROM, I/O адреса USB GPIO/SPM/EEPROM, разметка SRAM, `BOOT_AT` |
| `source/block64_protocol.inc` | Коды команд, состояния, ошибки, ограничение Block64, версия v3.3 |
| `source/vusb_phy.inc` | Битовые тайминги USB, NRZI, bit stuffing, EOP, ACK/NAK и существующая CRC16 |
| `source/vusb_ep0.inc` | EP0 SETUP/DATA обработка, буферизация ответов из SRAM/Flash, разбивка на 8-байтовые USB DATA-пакеты |
| `source/vusb_standard.inc` | Стандартные запросы USB: GET_DESCRIPTOR, GET_CONFIGURATION, SET_ADDRESS и др. |
| `source/micronucleus_t88_block64.S` | RESET/инициализация, основная логика, Flash SPM, EEPROM, команды Block64 |

ВНИМАНИЕ: `vusb_*.inc` **не являются самостоятельными объектными файлами**. Они включаются на тех же местах исходного единого ASM, где код находился в Pass10. Поскольку отсутствуют ABI-обёртки, новые CALL/RET не возникают, метки и машинные инструкции остаются на прежних адресах; регрессия это подтверждает бинарно.

Для новой платформы недостаточно поменять только номера регистров. Весь USB PHY рассчитан на 16 МГц и конкретные AVR-инструкции/пинмап; придётся повторно измерять такты всех путей. Защита загрузчика от записи сейчас программная.
