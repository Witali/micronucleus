from pathlib import Path
p=Path(__file__).resolve().parent.parent/'source/micronucleus_t88_block64.S';s=p.read_text()
a='''    std     Y+15, r23
    /* Once a zero-length STATUS packet has been queued, arm deferred SPM.
       Neither erase nor page-write may run during control OUT data/status. */
    rcall   block_note_status_prepared
'''
b='''    std     Y+15, r23
    /* Only a FLASH_WAIT_PREP request needs the deferred SPM transition.
       This is the sole caller of the old 12-byte status-prepared helper. */
    ldd     r18, Y+48
    cpi     r18, ST_FLASH_WAIT_PREP
    brne    L1e64
    ldi     r18, ST_SPM_WAIT_SENT
    std     Y+48, r18
'''
assert s.count(a)==1;s=s.replace(a,b)
a='''/* Called when zero-length status DATA1 has been queued on EP0. */
block_note_status_prepared:
    ldd     r18, Y+48
    cpi     r18, ST_FLASH_WAIT_PREP
    brne    block_service_return
block_status_pending:
    ldi     r18, ST_SPM_WAIT_SENT
    std     Y+48, r18
    ret

'''
assert s.count(a)==1;s=s.replace(a,'')
p.write_text(s)
