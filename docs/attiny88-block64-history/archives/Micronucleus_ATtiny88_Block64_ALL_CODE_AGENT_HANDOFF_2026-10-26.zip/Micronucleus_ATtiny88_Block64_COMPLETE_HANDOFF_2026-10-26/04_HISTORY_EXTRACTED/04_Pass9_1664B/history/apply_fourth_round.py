from pathlib import Path
p=Path(__file__).resolve().parent.parent/'source/micronucleus_t88_block64.S'
s=p.read_text()
def change(a,b,label):
 global s
 assert s.count(a)==1,(label,s.count(a))
 s=s.replace(a,b);print(label)
change('''    /* Address + length = 17-bit sum, reject carry and upper bounds. */
    mov     r18, r22
    mov     r19, r23
    add     r18, r24
    adc     r19, r1
    brcs    block_invalid_range
    /* Select one 16-bit exclusive bound: EEPROM=64, Flash=BOOT_AT. */
''','''    /* Avoid 17-bit address+length arithmetic: compare address <= bound-length.
       Both memory bounds are >=64, and 1<=length<=64 was checked above. */
    /* Select the exclusive end: EEPROM=64, Flash=BOOT_AT. */
''','Replace addition+wrap check with remaining-capacity check')
change('''block_check_selected_bound:
    cp      r20, r18
    cpc     r21, r19
    brcs    block_invalid_range
''','''block_check_selected_bound:
    sub     r20, r24
    sbc     r21, r1
    cp      r20, r22
    cpc     r21, r23
    brcs    block_invalid_range
''','Compare start address to last permitted start (bound-length)')
change('''    ldi     r18, 1
    std     Y+56, r18  /* SPM operation flag: 1=erase, 0=page-write */
    ldi     r18, RESULT_BUSY
    std     Y+55, r18
''','''    ldi     r18, RESULT_BUSY
    std     Y+56, r18  /* SPM operation flag: 1=erase, 0=page-write */
    std     Y+55, r18
''','Reuse busy=1 as erase flag=1')
p.write_text(s)
