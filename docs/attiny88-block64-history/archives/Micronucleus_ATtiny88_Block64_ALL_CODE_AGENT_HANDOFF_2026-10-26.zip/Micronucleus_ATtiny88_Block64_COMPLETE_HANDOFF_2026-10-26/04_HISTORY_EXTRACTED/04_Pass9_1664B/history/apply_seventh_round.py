from pathlib import Path
p=Path(__file__).resolve().parent.parent/'source/micronucleus_t88_block64.S';s=p.read_text()
def change(a,b,label):
 global s
 assert s.count(a)==1,(label,s.count(a))
 s=s.replace(a,b);print(label)
change('''    cp      r18, r19
    brne    block_eeprom_more_bytes
    rjmp    block_complete
block_eeprom_more_bytes:
''','''    cp      r18, r19
    breq    block_complete
block_eeprom_more_bytes:
''','EEPROM completion: use branch rather than branch+RJMP')
end='''    std     Y+56, r18
    ret

/* This hook runs only when the main USB polling window has expired.'''
new='''    std     Y+56, r18
    ret

block_complete:
    /* Finish EEPROM control-OUT with a ZLP; Flash finishes separately. */
    sts     0x0100, r1
    rjmp    block_complete_flash

/* This hook runs only when the main USB polling window has expired.'''
change(end,new,'Move completion block within relative-branch range')
change('''block_complete:
    /* R1 is maintained zero; reuse it directly to queue the ZLP. */
    sts     0x0100, r1
    rjmp    block_complete_flash

old_vendor_dispatch:
''','''old_vendor_dispatch:
''','Remove former EEPROM completion location')
change('''    ldd     r18, Y+56
    tst     r18
    brne    block_flash_erase_only
    rjmp    block_commit_flash

block_flash_erase_only:
''','''    ldd     r18, Y+56
    tst     r18
    breq    block_commit_flash

block_flash_erase_only:
''','Erase/write: branch directly to commit, fall through to erase')
p.write_text(s)
