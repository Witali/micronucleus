from pathlib import Path
p=Path(__file__).resolve().parent.parent/'source/micronucleus_t88_block64.S'
s=p.read_text()
def replace(old,new,label):
 global s
 assert s.count(old)==1,(label,s.count(old))
 s=s.replace(old,new)
 print(label)
replace('''    ldd     r18, Y+28
    tst     r18
    brne    block_invalid_range
    cpi     r16, 2
    brsh    block_invalid_range
    ldd     r24, Y+29
    ldd     r18, Y+30
    tst     r18
    brne    block_invalid_range
''','''    /* Combine the reserved high byte of wIndex and wLength. */
    ldd     r18, Y+28
    ldd     r19, Y+30
    or      r18, r19
    brne    block_invalid_range
    cpi     r16, 2
    brsh    block_invalid_range
    ldd     r24, Y+29
''','Shared invalid request high-byte guard')
replace('''    ldi     r20, 64
    ldi     r21, 0
    tst     r16
    brne    block_check_selected_bound
    ldi     r20, (BOOT_AT & 0xff)
    ldi     r21, (BOOT_AT >> 8)
block_check_selected_bound:
''','''    ldi     r20, 64
    ldi     r21, 0
    tst     r16
    brne    block_check_selected_bound
#if (BOOT_AT & 0xff) != 64
    ldi     r20, (BOOT_AT & 0xff)
#endif
    ldi     r21, (BOOT_AT >> 8)
block_check_selected_bound:
''','Exploit equal low bytes of EEPROM=64 and Flash boundary=0x1940')
replace('''    ldi     r18, RESULT_BOUNDS
    std     Y+55, r18
    ldi     r18, ST_ERROR
    std     Y+48, r18
''','''    /* Both RESULT_BOUNDS and ST_ERROR are value 2. */
    ldi     r18, RESULT_BOUNDS
    std     Y+55, r18
    std     Y+48, r18
''','Reuse equal error-state and error-reply constant')
replace('''block_vendor_dispatch:
    ldd     r18, Y+23         /* complete bmRequestType (IN/OUT) */
    cpi     r18, 0xc0
    breq    block_vendor_in
    cpi     r18, 0x40
    breq    block_vendor_out
    rjmp    block_reject

block_vendor_in:
    cpi     r25, OP_INFO
    breq    block_info
    cpi     r25, OP_STATUS
    breq    block_status
    cpi     r25, OP_READ
    breq    block_read_setup
    rjmp    block_reject

block_vendor_out:
    cpi     r25, OP_WRITE
    breq    block_write_setup
    cpi     r25, OP_ERASE_PAGE
    brne    block_vendor_not_erase
    rjmp    block_erase_setup
block_vendor_not_erase:
    cpi     r25, OP_RUN
    breq    block_run
    rjmp    block_reject
''','''block_vendor_dispatch:
    ldd     r18, Y+23         /* complete bmRequestType (IN/OUT) */
    cpi     r18, 0xc0
    breq    block_vendor_in
    cpi     r18, 0x40
    brne    block_reject

block_vendor_out:
    cpi     r25, OP_WRITE
    breq    block_write_setup
    cpi     r25, OP_ERASE_PAGE
    brne    block_vendor_not_erase
    rjmp    block_erase_setup
block_vendor_not_erase:
    cpi     r25, OP_RUN
    breq    block_run
    rjmp    block_reject

block_vendor_in:
    cpi     r25, OP_INFO
    breq    block_info
    cpi     r25, OP_STATUS
    breq    block_status
    cpi     r25, OP_READ
    breq    block_read_setup
    rjmp    block_reject
''','Fall through for vendor OUT dispatch rather than jumping')
p.write_text(s)
