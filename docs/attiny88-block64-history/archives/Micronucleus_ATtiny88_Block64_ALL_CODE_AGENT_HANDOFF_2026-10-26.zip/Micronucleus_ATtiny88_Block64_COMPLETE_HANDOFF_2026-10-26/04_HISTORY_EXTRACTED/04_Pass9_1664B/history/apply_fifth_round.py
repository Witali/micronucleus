from pathlib import Path
p=Path(__file__).resolve().parent.parent/'source/micronucleus_t88_block64.S';s=p.read_text()
def change(a,b,label):
 global s
 assert s.count(a)==1,(label,s.count(a))
 s=s.replace(a,b); print(label)
change('''    cpi     r18, ST_RUN
    brne    block_service_return
    rjmp    block_service_run
block_service_return:
    ret
''','''    cpi     r18, ST_RUN
    brne    block_service_return
    /* Inline the sole RUN dispatch, remove RCALL trampoline and a RET. */
    lds     r18, 0x010f
    cpi     r18, EP0_NAK
    brne    block_service_return
    rjmp    L1eac
block_service_return:
    ret
''','Merge RUN dispatch into the only caller')
change('''block_service_run:
    /* TX length reverts to NAK (0x5A) when status packet has been sent. */
    lds     r18, 0x010f
    cpi     r18, EP0_NAK
    brne    block_run_wait
    rjmp    L1eac
block_run_wait:
    ret

''','', 'Remove unused stand-alone RUN routine')
# Move reject body (independent terminal branch) beside write-bad, making write-bad fall through.
start=s.index('block_reject:\n');end=s.index('\n/* Validate wValue+wLength',start)
body=s[start:end]
s=s[:start]+s[end:]
change('''block_write_bad:
    rjmp    block_reject

/* ERASE_PAGE''','''block_write_bad:
'''+body+'''\n\n/* ERASE_PAGE''','Coalesce write-invalid fallthrough with shared reject')
p.write_text(s)
