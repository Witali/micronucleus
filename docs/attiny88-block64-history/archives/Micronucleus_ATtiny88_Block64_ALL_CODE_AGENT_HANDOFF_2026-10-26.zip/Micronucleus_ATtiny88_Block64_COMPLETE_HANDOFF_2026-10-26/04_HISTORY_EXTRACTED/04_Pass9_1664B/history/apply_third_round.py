from pathlib import Path
p=Path(__file__).resolve().parent.parent/'source/micronucleus_t88_block64.S';s=p.read_text()
def change(a,b,label):
 global s
 assert s.count(a)==1,(label,s.count(a))
 s=s.replace(a,b);print(label)
change('''L1d9c:
    ldi     r28, 0x00
    ldi     r29, 0x01
    ldd     r24, Y+18
''','''L1d9c:
    /* Y=0x0100 from the immediately preceding block_memory_service call;
       every returning path of that routine preserves Y. */
    ldd     r24, Y+18
''','Remove duplicated USB context pointer after service')
change('''    ldd     r20, Y+49
    tst     r20
    breq    block_out_flash
    ldi     r20, ST_WRITE_EEPROM
    rjmp    block_out_set_state
block_out_flash:
    ldi     r20, ST_FLASH_WAIT_PREP
    /* The last DATA OUT byte only queues the status-stage ZLP. */
    std     Y+0, r1
block_out_set_state:
    std     Y+48, r20
''','''    /* For type 0/1 select 6=FLASH_WAIT_PREP or 5=WRITE_EEPROM. */
    ldd     r17, Y+49
    ldi     r20, ST_FLASH_WAIT_PREP
    sub     r20, r17
    std     Y+48, r20
    tst     r17
    brne    block_out_return
    /* The last FLASH DATA OUT byte queues the status-stage ZLP. */
    std     Y+0, r1
''','Derive EEPROM/Flash service state from memory type')
p.write_text(s)
