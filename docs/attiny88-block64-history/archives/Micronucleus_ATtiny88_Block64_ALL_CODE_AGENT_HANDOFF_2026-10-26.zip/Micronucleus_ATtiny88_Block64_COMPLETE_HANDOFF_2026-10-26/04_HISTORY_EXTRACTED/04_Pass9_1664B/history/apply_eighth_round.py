from pathlib import Path
p=Path(__file__).resolve().parent.parent/'source/micronucleus_t88_block64.S';s=p.read_text()
def change(a,b,label):
 global s
 assert s.count(a)==1,(label,s.count(a))
 s=s.replace(a,b);print(label)
change('''    rcall   block_validate_range
    brcs    block_read_range_ok
    rjmp    block_reject
block_read_range_ok:
''','''    rcall   block_validate_range
    brcc    block_reject
block_read_range_ok:
''','Conditional branch to nearby common request rejection')
change('''    cpi     r18, ST_ERROR /* 0=IDLE, 1=DONE allow run; others reject */
    brlo    block_run_ready
    rjmp    block_reject
block_run_ready:
''','''    cpi     r18, ST_ERROR /* 0=IDLE, 1=DONE allow run; others reject */
    brsh    block_reject
block_run_ready:
''','Run validation: fall through on allowed state')
change('''    cpi     r17, ST_RUN
    brsh    block_not_idle
    sbic    0x1f, 1
    rjmp    block_not_idle
    sec
    ret
block_not_idle:
    clc
    ret
''','''    cpi     r17, ST_RUN
    brsh    block_not_idle
    /* CPI already set C=1 for state<3; skip CLC if EEPE=0. */
    sbic    0x1f, 1
    clc
    ret
block_not_idle:
    clc
    ret
''','Reuse carry from state comparison for idle-and-EEPROM-ready')
p.write_text(s)
