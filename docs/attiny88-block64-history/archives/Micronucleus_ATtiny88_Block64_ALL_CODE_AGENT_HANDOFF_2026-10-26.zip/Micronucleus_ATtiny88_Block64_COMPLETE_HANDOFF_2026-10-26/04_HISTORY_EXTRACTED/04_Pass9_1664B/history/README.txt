Patch scripts record sequential source transformations from a clean Pass8 copy.
Do not run them against the final Pass9 source; use PASS9_CHANGES.diff for review.
