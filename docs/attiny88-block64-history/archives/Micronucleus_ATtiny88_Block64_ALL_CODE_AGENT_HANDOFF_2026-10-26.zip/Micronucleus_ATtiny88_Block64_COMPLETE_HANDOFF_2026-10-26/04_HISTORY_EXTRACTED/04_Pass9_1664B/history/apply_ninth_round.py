from pathlib import Path
p=Path(__file__).resolve().parent.parent/'source/micronucleus_t88_block64.S';s=p.read_text()
a='''    cpi     r17, ST_RUN
    brsh    block_not_idle
    /* CPI already set C=1 for state<3; skip CLC if EEPE=0. */
    sbic    0x1f, 1
    clc
    ret
block_not_idle:
    clc
    ret
'''
b='''    cpi     r17, ST_RUN
    brsh    block_idle_return    /* C=0 for state>=3: already busy */
    /* If EEPROM is idle, SBIC skips CLC: CPI left C=1 for state<3. */
    sbic    0x1f, 1
    clc
block_idle_return:
    ret
'''
assert s.count(a)==1;s=s.replace(a,b);p.write_text(s)
