# Block64 v3.1 — USB memory commands

ATtiny88 USB 1.5 Mbit/s Low-Speed, endpoint zero (EP0). DATA physical packet payload: 0..8 B; Control Transfer may carry 1..64 B over multiple DATA packets. Vendor requests:

| Name | bmRequestType | bRequest | wValue | wIndex | wLength | Payload/response |
|---|---|---|---|---|---|---|
| READ | `C0` | `10` | 16-bit byte start address | 0 Flash / 1 EEPROM | 1..64 | Device sends requested bytes, 8 per USB DATA packet |
| WRITE | `40` | `11` | 16-bit byte start address | 0 Flash / 1 EEPROM | Flash exactly 64, EEPROM 1..64 | Host sends DATA OUT packets, no implicit Flash erase |
| STATUS | `C0` | `12` | 0 | 0 | 1 | 0 OK, 1 busy, 2 invalid, 3 error |
| RUN | `40` | `13` | 0 | 0 | 0 | Start program; only when idle/done |
| ERASE_PAGE | `40` | **`14`** | **Flash page-aligned address** | 0 | **0** | **Standalone erase**, no DATA OUT |
| INFO | `C0` | `20` | 0 | 0 | 8 | Device geometry and features |

`INFO`: standard 8-byte Micronucleus layout, user bytes `0x193C` (6460), page 64, write delay hint, sig bytes `93 11`, features `0xE3` (bit1 = split erase/write). USB device `bcdDevice=0x0301`. Legacy Micronucleus 2.x and custom Block64 v3.0 tools are incompatible.

## Flash semantics

Physical Flash: 8,192 B, page 64 B. Region `0x0000..0x193F` is writable (101 pages); `0x1940..0x1FFF` is protected by software. User data region `0x0000..0x193B`; `0x193C..0x193F` is a reset postscript reserved for a relocated original RESET RJMP.

- ERASE_PAGE requires `wLength=0`, `wIndex=0`, aligned page address and page fully below `0x1940`.
- WRITE for Flash requires `wLength=64`, `wIndex=0`, a 64-byte aligned address and eight DATA OUT packets. The MCU does NOT perform erase or RMW.
- MCU defensively replaces the first word of a written page 0 with an `RJMP` into itself; host patching is performed as well.
- READ uses 1..64 bytes, bounded by `0x1940`; includes physical patched RESET and 4-byte postscript.
- Host must ERASE_PAGE before each WRITE. To change one byte of Flash, host reads all 64 bytes, modifies one, then ERASes/WRITEs all 64 bytes (host RMW).
- For full firmware upload, host generates complete pages offline; no pre-reading of Flash needed.
- Sending WRITE to a non-erased Flash page cannot restore previously cleared bits; host must verify by READ.

## Flash programming and USB status phase

At 16 MHz CPU, software USB cannot respond during SPM PGERS/PGWRT. Each action may halt CPU for up to 4.5ms (device datasheet). This protocol requires a cooperative host:

```
OUT ERASE_PAGE(page)     --> USB STATUS-IN ZLP
HOST: after successful transfer, do not issue requests for 18ms
IN  STATUS()            --> 00 OK
OUT WRITE(page,64B)     --> SETUP + eight DATA OUT + STATUS-IN ZLP
HOST: after successful transfer, do not issue requests for 18ms
IN  STATUS()            --> 00 OK
IN  READ(page,64)       --> compare all 64 bytes
```

The MCU changes the operation state to `ST_SPM_WAIT_SENT` when the regular EP0 packager creates the control-OUT status ZLP and only executes SPM in the main loop after the TX length indicates the status was physically transmitted and the poll window expired. **This does not establish that the host ACK was received.** Controller/link retries are not fully validated; protocol is experimental.

## EEPROM semantics

EEPROM address range `0x00..0x3F`, READ and WRITE 1..64 B. One physical EEPROM cell programmed per iteration of the main loop; no separate erase command is necessary. Program completion gates the status ZLP. Preserve EEPROM contents on chip erase only if EESAVE fuse is configured appropriately.

## Error and robustness contract

Malformed or out-of-range operations are rejected and may lead to USB timeout instead of a standard USB STALL; they must not perform `SPM`. Host controls page ordering and postscript invalidation. The device does **not** expose Fuse/Lock commands or act as a generic ISP programmer. Unsupported loss-of-ACK behavior and premature low-level ACK of malformed USB DATA require physical testing or a dedicated USB ACK state machine.
