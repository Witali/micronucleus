# Audits and remaining risks — Block64 v3.1

## What the automated tests cover

- Clang AVR assembly success, exact .text layout, Intel HEX per-record checksums.
- Flash page bounds; ERASE_PAGE only aligned pages below loader start, zero DATA bytes.
- Flash WRITE only full 64-byte pages, no on-chip LPM of the pre-existing page.
- SPM erases and writes separate, never implicitly combines them in one request.
- 8 DATA OUT packets and repeat PID suppression; CRC16 software validation.
- EEPROM 1..64 B reads and writes (instruction-level model, not real EEPROM timings).
- Status and deferred-SPM state: no SPM before zero-length status packet is queued, and no SPM before it is physically transmitted in the model.
- Host verifies full Flash pages via READ and constructs host-side RMW for partial page writes.
- Full program upload patches RESET and postscript, erases the postscript page first and restores it last; EEPROM is unchanged.
- Original assembly 508-byte USB bit engine and 44-byte CRC routine are byte-identical with the reference build, despite relocation.

## Not established by these tests

- Hardware D+/D− eye diagram, enumeration and behavior on Windows, Linux and real hubs.
- Lost USB ACK or corrupted DATA before the low-level ACK; the existing V-USB bit engine has known unresolved concerns.
- Behavior of USB hosts with unsolicited traffic while SPM halts the CPU.
- Real Flash endurance/brownout/fuse behavior, including self-programming permissions.
- Full boot-safe update under power loss: interruption while rewriting the reset page may require ISP recovery.

This is **experimental software**; preserve ISP recovery access until physical validation completes. Base AVR hardware timings: https://ww1.microchip.com/downloads/en/DeviceDoc/doc8008.pdf, section 19.
